The custom enchants are used through tags on items,
The way to obtain the enchants is dropping the designated item on the ground beside you and open the crafting table,
and the recipe varies for the type of item you want to enchant:

sword: 3x3 copper blocks
axes: 3x3 amethyst blocks
shovel: 3x3 grass blocks
pickaxe: 3x3 iron blocks
armor: 3x3 gold blocks
trident : 1 diamond block
bow: 1 wither skull
shield: 1 heart of the sea

DESCRIPTION of each enchantment
	weapons
toxic - color 1-5 : gives poison when attacking 100%
Ice Aspect - color 1-2 : gives slowness when attacking 100%
Wither - color 1-5 : gives wither when attacking 100%
LifeSteal- color 1-5 : chance to heal 5%-25%
lightning -color 1-5 :chance to summon lightning 5-25%
Deathbringer-color 1-2: instant dmg 100%
Wise -color 1-5 :gives more xp every hit
Disorient - color 1-5 :gives a chance to make the entity u hit face away from u 5-25%
Execute - color 1-3 : kills a player when they r at 3 hearts or less 
Entangled - color 1-3 :puts entity in cobweb after attacking 5-15%
Shield - color 1-5: attacking has a chance to give u absorption hearts 5-25%
Shroud - color 1-3 attacking gives blindness, lasting longer per lvl
Royal Hunger- color 1-3: attacking has a chance to retore hunger bars 5-15% 

	armor
Cyborg - color 1-3: gives speed 1, jump 3, speed 2 jump 4, speed 3 jump 5
holy -color 1-3 : gives glowing, strength and resistance-helmet holy 1 gives glowing, holy 2 adds strength, holy 3 adds resistance
drunk - color 1-2 :gives naseau and strength (2nd lvl adds strength 2)-chestplate
Fishman -color 1 : gives water breathing
Assassin - color 1-4 : gives invis, speed 1-3, then 4 gives strength 1
rigorous -color 1-5 : 5-25% chance to heal when taking dmg not stackable
Block - color 1-5 : gives 5-25% chance to be invincible and "block the attack" (leggings only)
Frozen- color 1-5 : gives a 5-25% chance to make ur attacker have slowness 2
Cactus - color 1-5 : has a chance to hurt everything around you when getting attacked 5-25%
Blessed - color 1-5 : getting attacked has a chance to remove debuffs on you (poison, wither, slowness, weakness, naseua, blindness, darkness)
Last stand- color 1-5 :going to 2hp gives u regen 3, resistance 4 for 15 seconds, instant health 2 at max lvl cooldown 5 minutes
Wolf Master - color 1-5: getting attacked has a chance to spawn wolves 5-25% chance and increases the amount of wolves

	shield
Bash- color 1-2: 10-25% chance to deal dmg when blocking dmg to nearest enemy
Rejuvenate-color 1-2 :using a shield gives regen regen 1-2
Growth - color 1-5 : gives 2hp per lvl
Nimble - color 1-5 : gives +.001 speed per lvl
Wall - color 1-5 : kb resistance 10%-50%

	bow/crossbow 
escape- crouching with a bow in hand will launch the player upward and give slowfalling

	trident
same with all weapons and..
Blast- explodes around the trident 3 times after throwing one

	tools
magnet - color 1 : puts items mined into inventory
auto smelt -color 1 : auto smelts items, like iron, gold, copper, ancient debris, and sand
Celerity - color 1-3: gives haste 1-3 when holding 100%
